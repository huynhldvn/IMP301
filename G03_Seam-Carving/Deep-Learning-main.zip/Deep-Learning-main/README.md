# An Implementation of Seam-Carving
<img src="https://github.com/pntnone/Deep-Learning/blob/main/test.gif" width="400">

### Original Paper: Seam Carving for Content-Aware Image Resizing 
(Shai Avidan - Ariel Shami)


